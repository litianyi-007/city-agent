# 申报后评委对抗审查补充

日期：2026-10-07。本文是 production-materials-v4 当前导出快照的补充审查；不覆盖原 `JUDGE-AUDIT-2026-10-07.md`、已提交主稿或原始实验。运行配置以各 run.platformCommit 为准，材料工具以 publisherCommit 为准。历史视频保持原来源，不能当作新版真实模型交付录屏。

## 评委可实际验证什么

公开 `https://litianyi-007.github.io/city-agent/production/` 提供三项可信固定 Mock 的交互、原始证据、PDF/MD/视频与安装指南；不运行模型后台、不接收 Key、不支持网页输入新需求自动开发。首屏明确指向“本地输入新需求”。评委按本包完整 publisher commit 安装 Node 22.19+、npm ci、Chromium，构建并启动独立 4420 服务后，可在生产工作台新建需求、配置六角色独立模型/Key、可选 Jev、预算并启动。新建操作清空原 Mock 题目与验收，避免只换一句话却测试旧需求。

## 本轮致命疑问与核对

| 问题 | 当前证据与处理 | 不能推导的结论 |
| --- | --- | --- |
| 在线按钮能否新生成产品？ | 公共入口是固定案例；真实编辑器与八步安装/配置指南分列。 | 不宣称免安装在线后台。 |
| PM 的 revise 是否实际执行？ | planning-loop-v1 由原产品→研究→PM重调；旧完整研究/计划来源校验并供独立评审；共用两次预算。免费专项已覆盖 stop、权限缺失、取消、预算、早冻结负例。 | CAMERA-08 PM为proceed，不能当真实再规划实证。 |
| Verifier 接受文字是否被冒用？ | CAMERA-08 reason 未转义引号，严格 JSON 失败，未冻结/研发/Gate；原始输出和成本保留。 | 不以“accept”字样或修补后的JSON证明通过。 |
| Jev 是否已实现、是否节省费用？ | TypeSafe 托管 Jev 已接入；06/07前三阶段六次均升级独立LLM，声明价额外0.001863288 USD，未省调用。 | 不把评分集中度叫准确率，不把托管Jev等同AnyJev SDK，不宣称已证实收益。 |
| 是否隐藏失败/成本未知？ | CAMERA-01～08异配置探索全部归档；05/06总usage unknown与已知小计分列；08 14次HTTP、106043/7768 Token、估算0.030952776 USD完整报告。 | 不混为同配置稳定成功率，不用unknown填零或预测填实测。 |
| 是否真正安全执行仓库代码？ | 模型Key留控制面；受限HTML为Chromium截图；摄像头仅严格场景JSON＋可信运行时。无已验证容器，生成Node/shell执行未开放。 | worktree、浏览器截图都不是任意代码安全沙箱。 |
| 是否侵犯虚拟社会开发线？ | 独立branch/worktree/端口/数据；发布只production子树，根页面/assets/submission等全部SHA与mode/type必须不变，并发推进停止。 | 不编辑另一worktree、不移动Tag、不推main。 |

## 结果口径与下一验收

三项自拟 Mock 证明新建/扩展/Bug 的工程行为 Gate，不是三项真实业务需求。八次摄像头真实探索完整需求交付仍0；未达到一次真实最小闭环，不宣称稳定 L4/L5。申报基线六次真实四角色失败另留原版本。旧申报正文继续按其原版本阅读，本包新增真实账本、安装指引与审查用于补充，不倒填旧结果。

下一步优先采用原生结构化传输减少语法失效，先免费验证，不人工修补模型回答、不松验收或增加返修。真实最终 Gate 通过后才能登记最小有界闭环；实体手势与相机由用户主动操作验收。Verifier效益需固定独立候选及Oracle做同条件对照；18池/54次评审计划尚未执行。受控仓库须先有验证过的容器；九次稳定性实验须预登记并确认整批预算。

[Jev官方语义独立复核](https://github.com/litianyi-007/city-agent/blob/fb1bd5ac241a07a894364e5b624c9e75989e01c3/docs/production/JEV-SEMANTICS-REVIEW-2026-10-07.md)说明本地±0.005精度假设没有官方承诺，不能把历史arithmetic-drift直接定性为供应商计算错误；AnyJev与托管Jev的confidence含义不同。下一版不得仅扩大容差追通过，也不把模型评分当行为验证。

工程数字以当前 [批次记录](https://github.com/litianyi-007/city-agent/blob/fb1bd5ac241a07a894364e5b624c9e75989e01c3/docs/production/BATCH-CAMERA07-CHECKS.md)、[最新任务](POST-SUBMISSION-PLAN.md) 和各实验 RESULT 为准。材料文件一致性由manifest/hash校验，hash不是防篡改签名；外层Codex建设平台、工程Mock和平台内部真实执行三类证据必须分开。
