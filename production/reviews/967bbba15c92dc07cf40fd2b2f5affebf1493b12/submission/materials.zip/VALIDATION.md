# 第一批工程验证与真实验证

## 当前补充（2026-10-07，历史段落不回写）

[CAMERA-09](https://github.com/litianyi-007/city-agent/blob/967bbba15c92dc07cf40fd2b2f5affebf1493b12/docs/production/experiments/CAMERA-09/RESULT.md)已完成一次最小真实有界场景交付，冻结source24256f9、11/11行为Gate、0返修，76.602秒、18实际HTTP、估算0.037964112 USD。完整摄像头/真实视觉/实体设备仍分别验收，不算完整良品或稳定L5。

后续pending计量修补、Verifier开发语料与历史证据验证见[BATCH-CAMERA09-CHECKS](https://github.com/litianyi-007/city-agent/blob/967bbba15c92dc07cf40fd2b2f5affebf1493b12/docs/production/BATCH-CAMERA09-CHECKS.md)，当前六角色Key已由用户配置在本分支页面，未迁移别线。新公开材料以publication-manifest/receipt为准，旧段落的Key未配置、当时未调用/未发布与189/229项工程数字均是历史时点，不是现在状态。[本文更新前留底](https://github.com/litianyi-007/city-agent/blob/967bbba15c92dc07cf40fd2b2f5affebf1493b12/docs/production/archive/2026-10-07-before-camera09/VALIDATION.md)。

## 审查前基线已验证（历史记录）

- Node 22.22.3，全套单测189/189，墙钟11.685秒。
- 浏览器11/11，墙钟38.4秒；包含原虚拟社会人口/问卷/两类调查回归，以及生产三题实际行为、配置复制、移动端、Jev Key轮换和异步取消。
- TypeScript、Vite生产与Pages构建通过；没有发布Pages。
- Jev数值协议v2：21项适配器反例；独立免费属性检查111个Score与50个Choice；保留合法舍入、拒绝联合不可能分布与rubric标签篡改。属性检查不是校准证明。
- v2真实决策对照3请求：含弃权选中Gate2/3；另有v1数值协议失败和混合管线uncertain失败。详见EXPERIMENTS，不覆盖负结果。
- 原始供应商usage缺失不等同SDK默认0；保留实际已报告0。Harness每次至多1个上游POST，取消关闭请求/浏览器，重启不自动重放。
- API路径、符号链接、未知费用、预算停止、有限两次返修、冻结Gate、输入镜像假验收与PATCH默认重置均有负例。

## 未验证/未完成

新分支六角色生成模型Key未配置：真实内部模型编写与自主交付未实测，不称“最小真实闭环通过”或L4认证。3题是用户授权自拟，不满足真实需求来源条款。受控仓库、容器Node/shell执行、lockfile/patch交付和九次稳定性实验仍待实施；不降级到宿主执行生成脚本。

Key设置只回显状态；临时Jev凭据已入本线加密控制面，需要用户刷新后从页面替换。共享修订独立提交`d62b857`供另一线审查，不自动合并。

## 本轮评委审查修复

本轮新增反例覆盖生成页面延迟导航、无限循环/截图取消清理、Key的JSON转义与属性名脱敏、协议元数据碰撞、输入选择器别名伪装业务断言、中断JeV的未知HTTP请求数、导出血缘和路径逃逸。新配置使用 `production-html-v2`、`production-acceptance-v2`、`visible-token-v1`；不改写旧实验。

原虚拟社会worktree、main、冻结Tag、历史原始运行和旧申报附件仍不修改。最新用户授权本轮只新增 `gh-pages:production/` 独立静态评审门户；完整后端没有对外部署。发布使用根目录其余tree/blob的SHA核验与非强制更新，不能覆盖旧虚拟社会入口。

未完成的发布、PDF视觉检查或公网实操不提前算通过。本轮不发起任何模型或Jev付费请求；开发工具用量与机器成本未知，不填零。

### 冻结前工程回归结果

- Node 22.22.3：最终全套工程单测 **229/229**，墙钟 **17.615 秒**（先前一轮228/228，15.971秒）。
- 独立数据与 4421 端口：浏览器回归 **13/13**，墙钟 **45.7 秒**。包含虚拟社会人口来源/两个开店调查/问卷回归，生产三题实际 Gate、复制/配置、PNG预览、失败Gate标题和中断JeV unknown。
- 公开门户专项 **4/4**：实际 Chromium 三题行为交互、键盘切换、深浅主题及 375/768/1024/1440 四宽度；没有外部请求。实际公网发布后的检查另见本地 publication-receipt 和最终交付说明，不提前填通过。
- 导出/发布安全专项：源目录/文件 symlink 与路径穿越、未登记必需 JSON、hash 缺失/不一致、普通 manifest、文件数与大小边界、exact可信fixture字节、凭据字段扫描及虚拟社会整棵树SHA不变。
- 首次实际重导出因旧包 `mock-package-v1-qa1` 的精确版本兼容缺失被拒绝；仅显式加入已登记QA版本，不接受任意版本后缀，18/18材料/发布安全回归通过。未改旧manifest或原始文件。
- TypeScript 与工程 Vite 构建通过；最终 clean commit 仍须重新构建与核对 provenance。
- 对全部 tracked + unignored source 文件进行秘密前缀扫描，未发现疑似真实凭据；运行数据、加密主密钥、产物与测试目录均在 ignore 内。扫描不是所有未知秘密的完备检测。
- 只读对比原目录的 `status --porcelain` 和 `diff --binary` 与审查开始快照一致；main HEAD 与冻结Tag不变。虚拟社会并行 worktree 可有它自己的修改，本线不写它。

PDF、ZIP、静态门户与公网文件只会继承旧原始证据（生成 commit 891fedc），材料渲染/审查 publisher commit 单列。本轮免费回归不冒充新的真实模型实验。
