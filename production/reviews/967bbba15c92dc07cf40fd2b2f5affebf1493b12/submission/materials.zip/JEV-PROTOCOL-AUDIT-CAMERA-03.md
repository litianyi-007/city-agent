# CAMERA-03：Jev 响应协议的免费独立审查

日期：2026-10-07。对象是已经结束的真实运行，不更改其配置、响应或失败状态。外层独立研究 Agent 与本地离线回放参与核查，均不算平台内部自主交付。

## 公开定义与本地假设

[官方 Score](https://docs.typesafe.ai/primitives/score) 规定 score 为各级编号乘概率的加权和；[API reference](https://docs.typesafe.ai/api#score-answer) 同样采用这个定义。Probability 的和为1，返回 legend 对应请求中的序数等级。查看日期为2026-10-07。

[官方 Confidence](https://docs.typesafe.ai/confidence) 将 Score 集中度定义为众数对应的加权绝对距离相对均匀分布距离的函数。五级时分母1.2；当前实现与该公式一致。它描述分布集中度，不是判断正确率或业务验收成功率。

已查看的官方页面没有承诺固定两位小数、最近舍入或 ±0.005 误差。因此本地 `jev-candidate-v2` 的每字段两位显示区间是明确披露的版本化兼容假设，不能当官方精度保证。本次证据只证明响应与公开定义及当前兼容假设不一致，不能确定供应商内部原因。

## 原样响应的数值核查

记录见 [run.json](https://github.com/litianyi-007/city-agent/blob/967bbba15c92dc07cf40fd2b2f5affebf1493b12/docs/production/experiments/CAMERA-03/run.json)，Jev rawResponse 未归一化或修写。

| c0_scope 项目 | 值 |
| --- | --- |
| score / confidence | 2.72 / 0 |
| 五级概率 | 0.07、0.21、0.06、0.21、0.45 |
| 显示概率和 / 加权均值 | 1 / 2.76 |
| 每个概率±0.005，真实和=1时的均值范围 | 2.73–2.79 |
| score±0.005的区间 | 2.715–2.725 |
| 区间是否相交 | 否 |

独立枚举单纯形顶点核验极值，避免仅重复生产环境的贪心算法。当前错误发生在加权均值检查，尚未进入其后的联合置信可行域检查。众数4的显示MAD=1.24，confidence=0本身是合理值。

即使未来确认其他显示精度，该候选的原始各维分数2.72/2.81/2.82低于3，集中度0/0.01/0.01及Choice 0.32低于0.5；不能因此直接放行。原产品候选还把明确的手势映射写成可选反向/none，存在业务覆盖风险，必须另经独立语义审查与最终行为Gate。

## 当前处理与下一版边界

当前v2维持协议错误即停止，不自动重试Jev、不偷偷进入LLM复核、不消耗剩余质量返修额度。失败已留在账本，不能追认成功。

下一版可先设计明确的诊断分类：缺字段/错ID/模型漂移/非法概率/未知usage等仍停止；仅经过严格分类的非安全算术不一致，丢弃Jev决策后最多转交一次独立LLM Verifier。必须新版本预登记，仍按冻结业务标准评审，保留异常原文，不降低任何分数门限或最终Gate。该策略本批未实现，不能写成既有能力。

在任何真实调用之前，新增免费反例须覆盖：损坏响应不能选优、语义错误被复核拒绝、复核超时/非法协议/预算未知停止、一次升级限制、取消、Key隔离和历史版本重放。对外向供应商发送诊断材料属于额外协调，本批未进行。

## 免费复现

`tests/jev-camera03-replay.test.ts` 使用已脱敏的真实记录与注入的Response；无实际网络调用、无新增费用。逐值比对原请求/原响应，拒绝相同c0_scope错误且保留完整usage。连同既有Jev客户端反例22/22通过，269.538毫秒。测试中的注入传输计数不是供应商实际HTTP请求。

```sh
env PATH="/Users/litianyi/.nvm/versions/node/v22.22.3/bin:$PATH" node --import tsx --test tests/jev-camera03-replay.test.ts tests/jev-client.test.ts
```
