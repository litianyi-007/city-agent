# 申报后的开发进度与任务顺序

日期：2026-10-07。申报已由用户提交；本文件管理后续工程推进，不覆盖已提交版本和历史证据。工作区为 `city-agent-autonomous-production`，分支为 `feature/autonomous-production`，原虚拟社会主线继续独立执行。

## 当前进度

| 模块 | 已完成的实现/验证 | 下一步 |
| --- | --- | --- |
| 六角色团队 | 产品、项目经理、研究、研发、测试、Verifier；独立模型/Key/单价配置、复制、脱敏。 | 简化首次安装后的配置路径。 |
| 生产工作台 | 新建自定义需求、独立来源/验收、明确用户声明类型、摄像头映射约束；单次消费预算授权、防重复提交，选中任务/轮询/取消迟到响应隔离。 | 保持一次明确授权对应一次启动；继续真实页面任务。 |
| 编排与质量门禁 | 版本化输出、验收语义/CSS预检、研发前冻结验收、实际浏览器Gate、全局最多两次返修；09冻结先于研发，11项行为通过。 | 用同一通用HTML链路运行第一个真实自拟网页任务；不新增题目专用分支。 |
| Verifier/Jev | 分阶段责任映射、完整rubric、不截断候选；09六次Jev均保留原始意见并升级独立LLM；登记pending及时使总量unknown，保留已知小计；三DEV池六候选实际Oracle核对。 | 对照评估设计已登记，但模型选优/省费效益未测；另批预算后执行，不将工程语料当模型成绩。 |
| 工程案例 | 三个固定Mock覆盖新建、扩展与Bug修复，已有实际交互与Gate记录。 | 新本地UI演练录屏与更直接的公共案例入口。 |
| 真实场景探索 | CAMERA-01～09原始账本；09在24256f9干净构建通过11项Gate，76.602秒、18次HTTP、估算0.037964112 USD，0返修/中途人工干预。七份API原字节与源scene/可信渲染器血缘复核，5项历史证据测试通过。 | 最小真实有界场景闭环通过；场景1/9、完整0/9仅是不同配置探索计数，不称稳定成功率。 |
| 摄像头能力 | 严格场景JSON、可信本地识别/Canvas运行时、固定资产验证、合成行为测试。 | 真模型场景Gate之后，再由用户主动进行实体设备验收。 |
| 安全与范围 | 独立worktree/数据/端口；Key留控制面；任意模型HTML不在用户浏览器执行；禁止宿主生成脚本。 | 容器硬门限之后才开放受控仓库。 |
| 材料与发布 | v4独立production子树已发布，固定c7b4f2e和八次探索快照；10页PDF及HTTP/hash核验，原根树SHA不变；旧主稿与206秒Mock视频来源保留。 | 准备v5独立附录纳入09首个有界成功，不让旧录屏冒充新模型成功；发布以新receipt为准。 |

## 当前入口的准确定位

`https://litianyi-007.github.io/city-agent/production/` 是“固定案例交互＋执行证据＋本地安装引导”的静态门户，不是在线模型后端，也不是只能阅读的README。可添加/完成/删除固定待办、筛选、验证空输入；这些操作不会产生新的研发任务。

真正的编辑器位于安装后的 `http://127.0.0.1:4420/#production`：打开“生产工作台”，编辑“需求原话”和“业务验收要求”，选“真实模型”，在“研发团队”配置六角色，在“决策设置”按需配置Jev，再授权预算并启动。即使可以启动任务，也须以最终冻结Gate记录判断交付效果。

## 后续任务与门限

| 优先级/任务 | 本批或下一批交付 | 验收门限 |
| --- | --- | --- |
| P0 入口导航 | 首屏三个明确入口：体验固定案例、本地输入新需求、查阅材料；长账本折叠，固定案例置于前部。 | 首屏无需读长文即可分辨静态/本地；键盘与375/768/1024/1440宽度可用；不增加假编辑器/Key输入；三Mock行为回归。 |
| P0 真实闭环修复（工程已完成） | 紧凑Verifier输出、验收语义预检、原测试角色有限纠错、平台与CSS覆盖责任。 | 非法reason、未解析占位符、计数不变量矛盾被准确反馈；合法纠错使用原角色且全局≤2次；旧实验不变，Gate缺陷以新版本修复；unknown/取消/超限停止。 |
| P0 新配置真实任务（09有界场景通过） | 原生JSON模式已实测；归档09七份原证据。下一纵向切片为原MOCK-01需求的真实HTML尝试，另编号/预登记，不带demoCaseId。 | 不人工修补输出、不松JSON/schema/Gate；共享≤2返修、unknown/取消/预算停止；真实HTML行为及PM再规划各据实际路径记录。 |
| P1 真实摄像头验收 | 场景数据Gate之后，主动授权本机相机，验证真实手势。 | 合成行为、真实视觉、实体设备、完整需求分别记录，避免混用。 |
| P1 首次体验（本地UI已完成） | 安装/配置引导保留；新增“新建自定义需求”操作，清空旧Mock编号/验收并让用户明确来源类型。 | 七项新增浏览器用例通过；Key不进入录屏/导出；缺配置给出下一步；不自动付费；仅修改原话不能沿用旧题验收，也不能自动标成真实业务需求。 |
| P1 Verifier效益评估 | 三个人工开发池/六份完整候选及实际行为Oracle已完成；正式独立候选集与无Verifier/LLM/Jev对照待执行。 | 同模型/任务/预算可比，报告接受率、错误、弃权、额外调用及费用；开发池不计正式18池/未见集，不以其夹具通过证明选优效益。 |
| P2 受控仓库执行 | 容器准备、路径/网络/资源/秘密/取消负例，再支持模板生成、增量、Bug修复。 | 未通过隔离硬门限不在宿主运行生成Node/shell；交付base commit/patch/lockfile/构建测试。 |
| P2 泛化与推广 | 两公开任务、一未见任务，各三次的预登记固定配置实验。 | 初始目标≥8/9且每类≥2；安全硬门限全过；修改配置重新版本；全部启动尝试进入账本。 |

在线真编辑器不是静态页扩容：若后续需要免安装的联网服务，另行设计认证、每用户Key/预算、执行隔离、滥用与并发控制，再取得外部部署授权。本批只发布已授权的production静态子树。

## 推进规则

优先免费实现和工程验证；真实模型执行前公布该新配置的调用/Token/时间/金额上限。模型调用、免费夹具、外层平台建设分开记账。原主线、冻结Tag、原始失败和已申报附件保留；用户已有本地ZIP不覆盖、不纳入源码。

最近工程记录见 [原生JSON批次](https://github.com/litianyi-007/city-agent/blob/967bbba15c92dc07cf40fd2b2f5affebf1493b12/docs/production/BATCH-JSON-OUTPUT-CHECKS.md)，独立实测见 [09结果](https://github.com/litianyi-007/city-agent/blob/967bbba15c92dc07cf40fd2b2f5affebf1493b12/docs/production/experiments/CAMERA-09/RESULT.md)，其[预登记](https://github.com/litianyi-007/city-agent/blob/967bbba15c92dc07cf40fd2b2f5affebf1493b12/docs/production/experiments/CAMERA-09/PRE-REGISTRATION.md)不回写；[06](https://github.com/litianyi-007/city-agent/blob/967bbba15c92dc07cf40fd2b2f5affebf1493b12/docs/production/experiments/CAMERA-06/RESULT.md)、[07](https://github.com/litianyi-007/city-agent/blob/967bbba15c92dc07cf40fd2b2f5affebf1493b12/docs/production/experiments/CAMERA-07/RESULT.md)、[08](https://github.com/litianyi-007/city-agent/blob/967bbba15c92dc07cf40fd2b2f5affebf1493b12/docs/production/experiments/CAMERA-08/RESULT.md)等失败原样保留。[当前补充审查](https://github.com/litianyi-007/city-agent/blob/967bbba15c92dc07cf40fd2b2f5affebf1493b12/docs/production/SUPPLEMENTAL-REVIEW-2026-10-07.md)保留旧审查历史；[Verifier效益对照方案](https://github.com/litianyi-007/city-agent/blob/967bbba15c92dc07cf40fd2b2f5affebf1493b12/docs/production/VERIFIER-EVALUATION-PLAN.md)与[开发语料](https://github.com/litianyi-007/city-agent/blob/967bbba15c92dc07cf40fd2b2f5affebf1493b12/docs/production/VERIFIER-DEV-CORPUS.md)分列。公开静态材料为已冻结版本，不因本地修改自动更新。本次全文[留底](https://github.com/litianyi-007/city-agent/blob/967bbba15c92dc07cf40fd2b2f5affebf1493b12/docs/production/archive/2026-10-07-before-camera09/POST-SUBMISSION-PLAN.md)。
