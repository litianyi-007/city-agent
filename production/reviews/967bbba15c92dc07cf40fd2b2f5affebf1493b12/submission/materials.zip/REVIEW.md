# CAMERA-09与v5材料的评委对抗性复核

2026-10-07。新增补充，不覆盖v4审查、已申报主稿或原始实验。材料导出publisherCommit、09实际平台24256f9、三Mock/历史视频c21c588和旧公开v4安装c7b4f2e分别标注；原视频/失败字节不变。

## 关键问题与证据

| 评委问题 | 已核证据 / 处理 | 结论边界 |
| --- | --- | --- |
| 有没有实际内部Agent从需求到交付？ | 09在干净构建从需求编辑器启动，六角色/12Harness/6Jev、测试→冻结→研发先后顺序、11实际Gate、PM typed proceed、0返修/0已记录中途人工干预；七API原字节/hash独立复核。 | 最小真实有界场景闭环通过；不是任意软件、完整摄像头或稳定L5。 |
| 产品是模型写出的应用吗？ | scene.json与研发raw.scene漂亮序列化逐字节相同；HTML固定可信JS/CSS/CSP与非执行场景JSON，hash对应运行时manifest。 | 内部模型生成场景DSL，平台运行时执行；不冒称模型独立编写了固定Canvas/MediaPipe代码。 |
| 原始输出全部完美吗？ | 严格JSON/schema及控制面的通过状态有证；原PM摘要仍混有规划措辞、产品手动步进/连续横移混述。 | 不修文案/覆盖原输出；这是后续phase-aware质量改进点，不以摘要自述替代硬Gate。 |
| 真的省钱或选到了多个答案中最佳吗？ | 09每阶段1候选，Jev4uncertain/2可信算术漂移，全升级独立LLM；声明价总0.037964112 USD。三DEV池六候选免费实际Oracle准备完成。 | 本次未减少LLM调用，DEV不计正式18池；未宣称多候选效益、概率校准或省费因果。 |
| Gate能证明真实手势和梦幻美感吗？ | 合成21点状态机、Canvas几何、整体可见/手动控制；hardware/full均false。外层浏览器手动查看另外记录。 | 不证明真实识别准确率、单个星/锥视觉、实体设备兼容或审美；实机由用户主动验收。 |
| 是否删除坏结果、unknown或扩大预算？ | 01～09不同配置探索全部保留；05/06总unknown；所有终态计入账本。pending总量修补保留小计，8纯注入测试。 | 有界场景1/9、完整0/9仅描述当前探索计数；非同配置稳定成功率，known subtotal不替代总额。 |
| 能直接用公开页输入新需求吗？ | 固定案例可在线免费操作，独立新需求编辑器位于本机4420；指南/固定源码/模型与预算入口明确。 | Pages不运行Harness、不收Key、不申请相机；独立安装不迁移作者数据库，不能自动看到旧运行。 |
| 新材料会影响原虚拟社会吗？ | 仅production worktree与端口；公开只production子树，非force、并发拒绝、整根其他tree SHA核对。 | 不编辑另一worktree/main/Tag/旧Release/其他公开子树。 |

## 免费验证与下一阶段

当前工程结果以[BATCH-CAMERA09-CHECKS](https://github.com/litianyi-007/city-agent/blob/967bbba15c92dc07cf40fd2b2f5affebf1493b12/docs/production/BATCH-CAMERA09-CHECKS.md)最终追加记录为准；历史冻结工程过程另见[BATCH-JSON-OUTPUT-CHECKS](https://github.com/litianyi-007/city-agent/blob/967bbba15c92dc07cf40fd2b2f5affebf1493b12/docs/production/BATCH-JSON-OUTPUT-CHECKS.md)，其中两次中间失败不因串行重跑通过而删除。

v5只新增09精确七档allowlist，index.html.txt不执行；包100文件/30MB单文件/100MB总、公开110文件与原树保护不放松。继承原档若与当前归档字节冲突拒绝，不只跳过并计算不同摘要；最终封包/PDF视觉/HTTP读回核验以实际发布receipt为准，不预登记已部署。

下一实测[HTML-01](https://github.com/litianyi-007/city-agent/blob/967bbba15c92dc07cf40fd2b2f5affebf1493b12/docs/production/experiments/HTML-01/PRE-REGISTRATION.md)为用户授权自拟待办原题的通用HTML真实生成，单次1USD、原Gate不放宽。三项真实业务需求、同范围人日/稳定性、实体相机和验证过的仓库容器各有独立门限；旧Mock不转标真实业务需求。公开材料阶段性展示创新，不虚构官方L4认证。
